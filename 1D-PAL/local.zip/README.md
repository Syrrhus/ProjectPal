(•‿•)
MainActivity: RecyclerView of backgrounds 
SubActivity: Chosen background + Avatar 

To do:
update subactivity and link to imageButtom (background)
